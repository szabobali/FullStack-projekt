﻿namespace webshop_projekt.Models
{
    public class Item
    {
        public Goods? Product {  get; set; }
        public int Quantity { get; set; }
    }
}
